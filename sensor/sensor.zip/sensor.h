class sensor {
    private:
        bool state = false;        
    public:
        bool get_state();
        void set();
        void clear();
};